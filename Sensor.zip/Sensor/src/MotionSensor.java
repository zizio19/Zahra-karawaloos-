public class MotionSensor extends Sensor{
    public MotionSensor (String id ,String location ) {
        super(id, location);

    }
    @Override
    public String getLabel() {
        return "Motion Sensor " + getId() + " " + getLocation()
                + " - triggered: " + isTriggered();
    }
    }

