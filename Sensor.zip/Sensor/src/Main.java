public class Main {

    public static void main(String[] args) {

        AlarmSystem alarmSystem = new AlarmSystem();

        DoorSensor doorSensor = new DoorSensor("D1", "hall");
        alarmSystem.addSensor(doorSensor);

        SmokeSensor smokeSensor = new SmokeSensor("S1", "storage");
        alarmSystem.addSensor(smokeSensor);

        MotionSensor motionSensor = new MotionSensor("M1", "office");
        alarmSystem.addSensor(motionSensor);

        MotionSensor motionSensor2 = new MotionSensor("M2", "garage");
        alarmSystem.addSensor(motionSensor2);


        alarmSystem.arm();

        alarmSystem.triggerById("D1");
        alarmSystem.triggerById("M1");
        alarmSystem.triggerById("M2");

        alarmSystem.printStatus();


        alarmSystem.disarm();

        alarmSystem.triggerById("S1");

        alarmSystem.printStatus();


        alarmSystem.resetAll();

        alarmSystem.printStatus();
    }
}