public class SmokeSensor extends Sensor{

    public SmokeSensor (String id ,String location ) {
        super(id, location);

    }
    @Override
    public String getLabel() {
        return "Smoke Sensor " + getId() + " " + getLocation()
                + " - triggered: " + isTriggered();
    }
        }