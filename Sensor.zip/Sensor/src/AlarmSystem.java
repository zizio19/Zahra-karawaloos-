import java.util.ArrayList;
import java.util.List;

public class AlarmSystem {

    private final List<Sensor> sensors;

    public AlarmSystem() {
        sensors = new ArrayList<>();
    }

    public void addSensor(Sensor sensor) {
        sensors.add(sensor);
    }

    private boolean armed;

    public void arm() {
        this.armed = true;
    }

    public void disarm() {
        this.armed = false;
    }

    public boolean isArmed() {
        return armed;
    }

    private boolean alarming;

    public boolean isAlarming() {
        return alarming;
    }

    public void triggerById(String id) {
        for (Sensor sensor : sensors) {
            if (sensor.getId().equals(id)) {

                if (sensor instanceof SmokeSensor || isArmed()) {
                    sensor.trigger();
                    alarming = true;
                }

                return;
            }
        }
    }

    public void printStatus() {
        for (Sensor sensor : sensors) {
            System.out.println(sensor.getLabel());
        }
    }

    public int getTriggeredCount() {
        int count = 0;

        for (Sensor sensor : sensors) {
            if (sensor.isTriggered()) {
                count++;
            }
        }

        return count;
    }

    public void resetAll() {
        for (Sensor sensor : sensors) {
            sensor.reset();
        }

        alarming = false;
    }
}