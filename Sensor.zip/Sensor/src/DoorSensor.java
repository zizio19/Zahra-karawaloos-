
public class DoorSensor extends Sensor {
    public DoorSensor(String id, String location) {
        super(id, location);

    }

    @Override
    public String getLabel() {
        return "Door sensor " + getId() + " " + getLocation()
                + " - triggered: " + isTriggered();
    }

        }



