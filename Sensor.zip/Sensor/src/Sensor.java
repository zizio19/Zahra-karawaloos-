public abstract class Sensor {
   private String id;
   private String location ;
   private boolean triggered;

    public String getLocation() {
        return location;
    }

    public String getId() {
        return id;
    }

    public boolean isTriggered() {
        return triggered;
    }

    public Sensor(String id, String location) {
        this.id = id;
        this.location = location;
    }

        public void trigger() {
            this.triggered = true;


            }
            public void reset () {
                this.triggered = false;
            }

    public abstract String getLabel();
}
